# Numeric estimation of selection rate, locus position and correction factor demands an initial value
# It can be determined visually on a plot
# convergence is not guaranteed if initial values are "too far" from the real value
# but these values yield correct result
# s<-0.05    
# x0<-0.5    
# e<-2      
s<-0.12      # Initial selection rate in favour of heterozygote (it is 1 for homozygotes) 
x0<-0.45     # Initial location of the selected gene (position in cM divided by 100!)
e<-1        # Initial correction factor (takes residual genotyping error into account)
param<-c(s,x0,e)

# map data are needed
dat<-read.table("LG15_map.txt", sep="\t", header=TRUE)
dat$x<-dat$dist/100
dat$heterozygote<-dat$h/(dat$a+dat$h)

freq<-function(x,param){
  # compute the expected heterozygote frequency, given a parameter set
  # heterozygote frequencies increase linearly with the distance to selected gene
  s<-param[1] 
  x0<-param[2]
  e<-param[3]
  ifelse(x/e<x0/e,(s+x0/e*(1-s)-x/e*(1-s))/(1+s),(s-x0/e*(1-s)+x/e*(1-s))/(1+s))
}

# objective function
target<-function(myparam)
  sum((dat$heterozygote-sapply(dat$x,freq, myparam))^2)

# find parameter set that minimises the objective function (newton-type method)
paramok<-nlm(target,param, hessian=T)$estimate


#Draw xy plot
with(dat,plot(x,heterozygote,xlim=c(0,1.05),ylim=c(0,0.5),xlab="abscisse (cM/100)",ylab="heterosygosity"))
xx<-seq(0,1,0.005)
y<-sapply(xx, freq,paramok)
lines(xx,y) # Expected with correction

parambis<-paramok
parambis[3]<-1 
z<-sapply(xx, freq,parambis)
lines(xx,z,lty=3) # Expected without correction



text(c(0.2,0.2,0.2), c(0.45,0.42,0.39), c(paste("s=", round(paramok[1],4)),
                                          paste("x=", round(paramok[2],4)),
                                          paste("e=", round(paramok[3],4))))

