#' Title Produces a linkage map with error corrections
#'
#' @param lg 
#' @param place 
#'
#' @return nothing
#' @export a map file and a xy plot
#'
#' @examples
correctmap <- function (lg,place=myplace) {
  # writes a file with corrected data and a map file with distances and allele frequencies
  # data entry
  file<-paste(lg,"txt",sep=".")
  file<-paste(place,file,sep="/")
  dat<-read.table(file,sep="\t",stringsAsFactors = FALSE,header=TRUE,row.names=1)
  #   loc<-dat[[1]]
  #   genotM<-t(dat[-1])
  loc<-rownames(dat)
  genotM<-t(dat)
  
  #Converts genotypes into strings
  genot<-sapply(1:nrow(genotM),function(x) paste(genotM[x,],collapse=""))
  observ<-transcode(genot,"abhu","0219") 
  N<-length(observ)
  correct<-correctGenotype2(observ) # Applies error correction
  after<-findCO2(correct) 
  xa<-apply(after,2,sum)/N*100 # after correction
  noisy<-findCO2(observ)
  xn<-apply(noisy,2,sum)/N*100 #without correction
  
  # produces an xy plot 
  plot(cumsum(xa),type="l",ylim=c(0,sum(xa)*1.3),
       xlab="loci",ylab="distance(cM)", main =paste("linkage distances", lg),frame.plot=FALSE)
  lines(cumsum(xn),col="red") # crossing-overs avec bruit

  legend("bottomright",c("estimated without corrections","estimated with corrections" )
         , lty=rep(1,24),col=c("red","black"),inset=0.02,cex=.7)
  nloc<-length(loc)
  f1<-sapply(1:nloc, function(x) sum( substr(correct,x,x)=="1") )
  f0<-sapply(1:nloc, function(x) sum( substr(correct,x,x)=="0") )
  #Outputs map
  posit<-c(0,cumsum(xa))
  names(posit)<-loc
  #posit<-t(t(posit))
  mapout<-cbind(posit, f0,f1)
  colnames(mapout)<-c("dist","a","h")
  # sauvegarder les positions des locus sur la carte
  outmap<-paste(lg,"_map.txt",sep="")
  outmap<-paste(place,outmap,sep="/")
  outcorr<-paste(lg,"_corrdat.txt",sep="")
  outcorr<-paste(place,outcorr,sep="/")
  #write.table(posit,outmap,sep="\t")
  write.table(mapout,outmap,sep="\t")
  corrout0<-transcode(correct,"0219","abhu")
  # ce qui suit donne une liste dont chaque élément est un vecteur de longueur 'nloc'. A corriger.
  # la fontion dans le sapply doit donner un vecteur et non une liste. (->fonction anonyme.)
  corrout<-sapply(corrout0, function(x) strsplit(x,split="")[[1]])
  #  corrout<-sapply(corrout,strsplit,split="")
  rownames(corrout)<-colnames(genotM)
  colnames(corrout)<-rownames(genotM)
  
  write.table(corrout,outcorr,sep="\t")
  c(sum(xa), sum(xn))
}




correctRules<-function(){
  # This is the F2 version (should work also for backcrosses!)
  # code: 
  #   0 first parent (recurrent parent in a BC)
  #   1 second parent (heterozygote in a BC)
  #   2 heterozygote (not used in BC)
  #   9 missing genotype
  #########################################################################
  # 'query' is the pattern collected in an individual genotype (a string)
  # the outcome is a string which may contain unwanted character
  # they are identified by 'problem' and replaced by 'correct' (see examples)
  #########################################################################
  # to produce alternative rule sets, just add/remove/alter rules
  # IMPORTANT: the length of the strings matched by 'problem' should 
  # have a fixed length, equal to 'length(correct)'
  # Remember that the order of rules counts!!!
  # To test new rules, use the following line as a template 
  # zzz<-zz<-"00090099999000990999999000";regmatches(zz,gregexpr("0990",zz,perl=TRUE)) <- "0000";rbind(zzz,zz)
  ########################################################################
  # new version with shorter missing sequences
  #########################################################################
  rule<-NULL

  # uniform sequences except sporadic errors or missing data. Problems are corrected.
  # Basically, this is the four-point method
  # example: "00010002000000990000" becomes "00000000000000000000"
  rule<-rbind(rule,cbind(query="0{3,}([129]{0,2}0{3,})*",
                         problem="[129]",
                         correct="0")) 
  rule<-rbind(rule,cbind(query="1{3,}([029]{0,2}1{3,})*",
                         problem="[029]",
                         correct="1"))
  rule<-rbind(rule,cbind(query="2{3,}([019]{0,2}2{3,})*",problem="[019]",correct="2"))
  
  # tandem error. Errors are corrected  
  # example: "000110900000022022000" becomes "000000000000000000000" 
  rule<-rbind(rule,cbind(query="0{3,}[12]0{1,2}[12]0{3,}" ,
                         problem="[12]",
                         correct="0"))
  rule<-rbind(rule,cbind(query="1{3,}[02]1{1,2}[02]1{3,}" ,
                         problem="[02]",
                         correct="1"))
  rule<-rbind(rule,cbind(query="2{3,}[01]2{1,2}[01]2{3,}" ,
                         problem="[01]",
                         correct="2"))
  
  # only one missing value, not taken in charge by previous rules. isolated missing data corrected
  # example:  "000900999990000" becomes "000000999990000"
  
  rule<-rbind(rule,cbind(query="0{3,}(90)*0{2,}" ,
                         problem="090",
                         correct="000"))
  rule<-rbind(rule,cbind(query="1{3,}(91)*1{2,}" ,
                         problem="191",
                         correct="111"))
  rule<-rbind(rule,cbind(query="2{3,}(92)*2{2,}" ,
                         problem="292",
                         correct="222"))

  # same as before but two missing values
  # example:  "000990999990000" becomes "000000999990000"
  rule<-rbind(rule,cbind(query="0{3,}(990)*0{2,}" ,
                         problem="0990",
                         correct="0000"))
  rule<-rbind(rule,cbind(query="1{3,}(991)*1{2,}" ,
                         problem="1991",
                         correct="1111"))
  rule<-rbind(rule,cbind(query="2{3,}(992)*2{2,}" ,
                         problem="2992",
                         correct="2222"))
  
  rule
}

correctGenotype2 <- function (noisy) {
  # create a corrected version of noisy genotyping data. 
  # see 'correctRules()'
  #To be improved: if more than x missing data in a row in the corrected file, if it is only due to missing data, simply copy the corresponding source.
  rule<-correctRules()
  # initialize with only missing data  
  corr<-rep(paste(rep("9",nchar(noisy[1])),collapse=""),length(noisy))
  for(i in 1:nrow(rule)) {
    found <- gregexpr(rule[i,"query"],noisy,perl=TRUE)
    matches <- regmatches(noisy,found)   # identified patterns
    condition <- sapply(matches,length) != 0
    if (sum(condition) > 0) {
      for (x in 1:length(matches[condition]))
        # corrects problems
        regmatches(matches[condition][[x]],gregexpr(rule[i,"problem"],matches[condition][[x]],perl=TRUE)) <- rule[i,"correct"]
      # replace identified patterns with corrected version
      regmatches(corr,found) <- matches
    }
  }
  corr
}



#&$&$&$&$&$&$&$&$&$&$&

transcode<-function(Data,code1, code2){
  # Convert data using a dufferent coding
  # Coding rules use "0129" while data are "ahbu 
  # code1 et code2 are character strings
  # order: parent 1, parent 2, heterozygote, missing
  # In backcrosses, parent 2 is not used but must be provided
  if(nchar(code1)!=nchar(code2)) stop("codes should have the same number of elements")
  code_1<-strsplit(code1,split="")[[1]]
  code_2<-strsplit(code2,split="")[[1]]
  for(i in 1:length(code_1)){
    regmatches(Data,gregexpr(code_1[i],Data))<-code_2[i]
  }
  Data
}

#&$&$&$&$&$&$&$&$&$&$&

findCO2 <- function (corr) {
  # locates crossing overs (CO) to intervals with missing data (code "9")
  # in case of missing data, intervals are assigned equally distributed CO probability.
  # This is the F2 version (works also for backcrosses!)
  pat<-"09*1|19*0|19*2|29*1" # 
  a<-gregexpr(pat,corr,perl=TRUE)
  out1<-NULL
  for(i in 1:length(corr)){
    zz<-rep(0,nchar(corr[1])-1)
    if(a[[i]][1]!=-1){
      beg<-as.numeric(a[[i]])
      end<-beg+attr(a[[i]], "match.length")-2
      for(j in 1:length(a[[i]])) zz[beg[j]:end[j]]<-1/(end[j]-beg[j]+1)
    }
    out1<-rbind(out1,zz)
    if(ncol(out1)!=length(zz)) cat(c(i,length(zz),ncol(out1),"\n"))
  }
  out1
}



plotPop2 <- function (pop,code="abhm",pal=c("magenta","cyan","plum","peachpuff4"),...) {
# New version of plotPop
# the matrix ix individual*locus  
# Use a four letter code (parent 1, parent2, heterozygote and missing)
    code_1<-strsplit(code,split="")[[1]]
  
  gr<-data.frame(ind=rep(1:nrow(pop),times=ncol(pop)),
                 loc=rep(1:ncol(pop),each=nrow(pop)),
                 gen=as.vector(pop),
                 h=rep(1,nrow(pop)*ncol(pop)),
                 v=rep(1,nrow(pop)*ncol(pop)))
  gra<-gr[gr$gen==code_1[1]&!is.na(gr$gen),]
  grb<-gr[gr$gen==code_1[2]&!is.na(gr$gen),]
  grh<-gr[gr$gen==code_1[3]&!is.na(gr$gen),]
  grm<-gr[gr$gen==code_1[4]&!is.na(gr$gen),]
  nrow(gra)+nrow(grb)+nrow(grh)
  plot(0,type="n",ylim=c(0,ncol(pop)),xlim=c(0,nrow(pop)),xlab="individual",ylab="locus",frame.plot=FALSE,...)
  rect(gra$ind-1,gra$loc-1,gra$ind,gra$loc,border=NA,col=pal[1]) 
  rect(grb$ind-1,grb$loc-1,grb$ind,grb$loc,border=NA,col=pal[2]) 
  rect(grh$ind-1,grh$loc-1,grh$ind,grh$loc,border=NA,col=pal[3]) 
  rect(grm$ind-1,grm$loc-1,grm$ind,grm$loc,border=NA,col=pal[4]) 
}

