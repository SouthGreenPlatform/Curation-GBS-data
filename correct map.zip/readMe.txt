Open 'master.r' in 'R'
Modify the first two lines according to the actual location of
1) of data and of
2) file 'doc carto.r'
Run the file. Note: plots have to be exported manually